package com.jwttoken.Jwt_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
